/meta1/.zarray: |{
"foo": 42,
"bar": "apples",
"baz": [1, 2, 3, 4]}|
