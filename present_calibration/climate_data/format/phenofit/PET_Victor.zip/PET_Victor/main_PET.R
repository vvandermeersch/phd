#######################################################
# Script to compute PET as required by Phenofit model #
#######################################################

# author : V. Van der Meersch
# date : 16/02/2022

wd <- "C:/Users/vandermeersch/Documents/CEFE/thesis/calibration/climate_data/format/phenofit/"

## Packages needed

library(future)
library(future.apply)
library(dplyr)


## Function needed

source(paste0(wd, 'functions/phenofit_compute_PET2.R')) # to calculate evapotranspiration, v2


## Settings

processeddata_folder <- "D:/climate/ERA5-Land/phenofit_format/"


## Run

system.time(phenofit_compute_PET2(1969:2000, processeddata_folder, method = "PenmanMonteith", ncores=2))
# 53 minutes for 30 years
gc()

